package org.usfirst.frc.team2186.robot.Vision;

public class AutoCounter implements Runnable {
	public void run(){
		
	}
}
